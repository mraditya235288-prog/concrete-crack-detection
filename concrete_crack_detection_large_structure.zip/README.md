# Concrete Crack Detection Web Application

## Project
Crack Detection in Concrete Structures

This Flask application connects the supplied OpenCV/NumPy/SciPy crack-detection pipeline to a responsive web interface.

### Pipeline
Image upload/camera capture → Flask → `detect_crack()` → OpenCV processing → contour measurement → severity → result dashboard.

### Input methods
1. Upload JPG/JPEG/PNG.
2. Capture a real image from the browser camera using `navigator.mediaDevices.getUserMedia()`.

Both methods use the same backend function.

## Installation

### Windows
```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

### macOS/Linux
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open:
`http://127.0.0.1:5000`

## Camera testing

On the same computer, `http://127.0.0.1:5000` is a secure context for browser camera access.

For a phone, the browser camera API normally requires a secure HTTPS origin. If you open the Flask app through a normal LAN HTTP address such as `http://192.168.x.x:5000`, some mobile browsers will block `getUserMedia()`. For phone testing, use an HTTPS development tunnel or deploy the application behind HTTPS.

The camera requests the rear/environment camera where the browser supports `facingMode: environment`.

## Calibration

The default is:
`100 pixels = 1 cm`

This is configurable in the UI. It is a project/demo calibration and should not be treated as a physically accurate measurement without a known reference scale or camera calibration.

## Report

The Download Report button creates a self-contained HTML report. It can be opened in a browser and printed/saved as PDF.

## Important algorithm note

The supplied algorithm is preserved. The backend adds only necessary integration changes:
- `pixels_per_cm` is configurable.
- a no-significant-crack result is returned when no valid contour is found.
- images are saved for web display.


## Large concrete structure support

The updated version is designed for larger bridge/flyover/building/beam/pillar/tunnel photographs.

### Structural mode
The default `Structural` mode:
- removes more tiny isolated/dot-like candidates,
- preserves elongated crack candidates,
- uses area + length + aspect-ratio filtering.

### Large image tiling
Images larger than the tile threshold are automatically processed using overlapping 640×640 regions with 80 pixels overlap. The same supplied OpenCV pipeline runs inside every tile and the detected masks are merged back into the original image.

This helps when a large bridge/concrete surface contains a small visible crack that would otherwise occupy too few pixels in the full image.

### Detection modes
- `Structural`: recommended for bridges and large structures.
- `Standard`: balanced filtering.
- `Sensitive`: keeps smaller crack candidates.

### Important limitation
A distant photograph cannot reliably detect a crack that is too small to occupy enough image pixels. For physical measurement, capture close enough to the concrete surface and use proper camera calibration or a known reference scale.
